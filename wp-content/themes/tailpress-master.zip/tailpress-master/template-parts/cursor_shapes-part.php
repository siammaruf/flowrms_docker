<div id="cursor-shapes-1" class="shapes">
    <div class="relative">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>
</div>
<div id="cursor-shapes-2" class="carousel-mouse-shape">
    <div class="relative h-full w-full">
        <div class="carousel-mouse">Drag<br>or click</div>
    </div>
</div>
<div id="cursor-shapes-3" class="insights-bg">
    <div class="relative h-full w-full">
        <div class="insight-img"></div>
    </div>
</div>
